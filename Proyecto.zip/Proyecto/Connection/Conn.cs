﻿using Microsoft.EntityFrameworkCore;
using Proyecto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Connection
{
    public class Conn: DbContext
    {
        public Conn(DbContextOptions<Conn> options) : base(options) {
            
        }
        public DbSet<Puesto> tbl_Puesto { get; set;}

        public DbSet<Empleado> tbl_Empleado{  get; set; }
        public DbSet<Clientes> tbl_Clientes { get; set; }
        public DbSet<Login> tbl_Login { get; set; }

        public DbSet<Proveedor> tbl_Proveedores { get; set; }

        public DbSet<Producto> tbl_producto { get; set; }
        public DbSet<Ventas> tbl_Ventas { get; set; }
        public DbSet<DetalleVenta> tbl_DetalleVenta { get; set; }

    
       public DbSet<DetalleCredito> tbl_DetalleCredito { get; set; }
        
        public DbSet<NotaCredito> tbl_NotaCredito { get; set; }
     
        

    }
}
