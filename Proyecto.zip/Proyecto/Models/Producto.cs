﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class Producto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdProducto { get; set; }
        //llave foranea
        [ForeignKey("Proveedor")]
        public int IdProveedor { get; set; }
        //obejto de la llave foranea
        [ForeignKey("IdProveedor")]
        public virtual Proveedor Proveedor { get; set; }

        [Required]
        [Column(TypeName ="Varchar(100)")]
        [Display(Name ="Nombre del Producto")]
        public string NombreProducto { get; set; }

        [Required]
        [Column(TypeName ="Varchar(150)")]
        [Display(Name ="Descripción")]
        public string Descripcion { get; set; }

        [Required]
        [Column(TypeName = "DateTime")]
        [Display(Name ="Fecha")]
        public DateTime Fecha { get; set; }

        [Required]
        [Column(TypeName ="Varchar(150)")]
        [Display(Name ="Ubicacion Fisica")]
        public string UbicacionFisica { get; set; }

        [Required]
        [Column(TypeName ="int")]
        [Display(Name ="Existencia Minima")]
        public int Existencia { get; set; }

        [Required]
        [Range(1, 100000)]
        [Column(TypeName ="float")]
        [Display(Name ="Precio")]
        public double Precio { get; set; }







    }
}
