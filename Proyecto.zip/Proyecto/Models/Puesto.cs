﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class Puesto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdPuesto { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Nombre del puesto")]
        public string NombrePuesto { get; set; }


        [Required]
        [Range(1, 100000)]
        [Column(TypeName = "float")]
        [Display(Name = "Salario")]
        public double Salario { get; set; }

    }
}
