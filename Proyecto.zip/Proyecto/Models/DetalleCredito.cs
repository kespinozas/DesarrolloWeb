﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class DetalleCredito
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdDetalleCredito { get; set; }

        [ForeignKey("NotaCredito")]
        public int IdNotaCredito { get; set; }
        [ForeignKey("IdNotaCredito")]
        public virtual NotaCredito NotaCredito{ get; set; }

        [ForeignKey("Producto")]
        public int IdProducto { get; set; }
        [ForeignKey("IdProducto")]
        public virtual Producto Producto { get; set; }


        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; }

        [Required]
        [Column(TypeName = "int")]
        [Display(Name = "Cantidad")]
        public int Cantidad { get; set; }


        [Required]
        [Column(TypeName = "float")]
        [Display(Name = "Sub Total")]
        public double SubTotal { get; set; }

        [Required]
        [Column(TypeName = "float")]
        [Display(Name = "IVA")]
        public double IVA { get; set; }

        [Required]
        [Column(TypeName = "float")]
        [Display(Name = "Total")]
        public double Total { get; set; }



    }
}
