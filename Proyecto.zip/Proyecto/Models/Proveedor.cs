﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class Proveedor
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdProveedor { get; set; }

        [Required]
        [Column(TypeName ="Varchar(100)")]
        [Display(Name = "Proveedor")]
        public string proveedor { get; set; }

        [Required]
        [Column(TypeName ="Varchar(100)")]
        [Display(Name = "Dirección")]
        public string DireccionProveedor { get; set; }

        [Required]
        [Column(TypeName ="Varchar(15)")]
        [Display(Name ="Telélefono")]
        public string Telefono { get; set; }

        [Required]
        [Column(TypeName ="Varchar(100)")]
        [Display(Name ="Correo Electronico")]
        public string Correo { get; set; }

    }
}
