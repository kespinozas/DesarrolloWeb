﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class Login
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdUsuario { get; set; }

        //clave externa
        [ForeignKey("Empleado")]
        public int IdEmpleado { get; set; }
        //objeto de la clave externa
        [ForeignKey("IdEmpleado")]
        public virtual Empleado Empleado { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display (Name ="Correo Electronico o Usuario")]
        public string correoUsuario { get; set; }

        [Required]
        [Column(TypeName="Varchar(25)")]
        [Display(Name ="Password")]
        public string Password { get; set; }

        [Required]
        [Column (TypeName ="Varchar(50)")]
        [Display (Name ="Perfil")]
        public string Perfil { get; set; }


    }
}
