﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class DetalleVenta
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdDetalleVenta { get; set; }

        [ForeignKey("Ventas")]
        public int IdVentas { get; set; }
        [ForeignKey("IdVentas")]
        public virtual Ventas Ventas { get; set; }

        //nombre del producto

        [ForeignKey("Producto")]
        public int IdProducto { get; set; }
        [ForeignKey("IdProducto")]
        public virtual Producto Producto { get; set; }

        //Cantidad del producto
        [Required]
        [Column(TypeName ="int")]
        [Display(Name ="Cantidad")]
        public int Cantidad { get; set; }

        [Required]
        [Column(TypeName ="float")]
        [Display(Name ="Precio")]
        public double Precio { get; set; }

        [Column(TypeName ="float")]
        [Display(Name="float")]
        public double PrecioTotal { get; set; }




    }
}
