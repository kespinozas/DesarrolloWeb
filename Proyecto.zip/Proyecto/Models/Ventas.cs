﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class Ventas
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdVentas { get; set; }

        [ForeignKey("Empleado")]
        public int IdEmpleado { get; set; }
        [ForeignKey("IdEmpleado")]
        public virtual Empleado Empleado { get; set; }

        [ForeignKey("Clientes")]
        public int IdClientes { get; set; }
        [ForeignKey("IdClientes")]
        public virtual Clientes Clientes { get; set; }

        [Required]
        [Column(TypeName ="Date")]
        [Display(Name ="Fecha ")]
        public DateTime Fecha { get; set; }




    }
}
