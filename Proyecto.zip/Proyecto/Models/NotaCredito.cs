﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class NotaCredito
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdNotaCredito { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name ="Nombre de La Empresa")]
        public string NombreEmpresa { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "NIT")]
        public string NIT { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Dirección")]
        public string Direccion { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Teléfono")]
        public string Telefono { get; set; }

    //foranea para Empleado
        [ForeignKey("Empleado")]
        public int IdEmpleado { get; set; }
        [ForeignKey("IdEmpleado")]
        public virtual Empleado Empleado { get; set; }

        //foranea para clientes
        [ForeignKey("Clientes")]
        public int IdClientes { get; set; }
        [ForeignKey("IdClientes")]
        public virtual Clientes Clientes { get; set; }

        [ForeignKey("Ventas")]
        public int IdVentas { get; set; }
        [ForeignKey("IdVentas")]
        public virtual Ventas Ventas { get; set; }

        [Required]
        [Column(TypeName ="DateTime")]
        [Display(Name ="Fecha")]
        public DateTime Fecha { get; set; }

       



    }
}
