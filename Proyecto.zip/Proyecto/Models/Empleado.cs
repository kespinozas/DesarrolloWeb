﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proyecto.Models
{
    public class Empleado
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdEmpleado { get; set; }

        //clave externa
        [ForeignKey("Puesto")]
        public int IdPuesto { get; set; }

        //Objeto que reperesenta la clave externa
        [ForeignKey("IdPuesto")]
        public virtual Puesto Puesto { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Nombre del empleado")]
        public string NombreEmpleado { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Apellido del empleado")]
        public string ApellidoEmpleado { get; set; }

        [Required]
        [Column(TypeName = "Varchar(150)")]
        [Display(Name = "Direccion Empleado")]
        public string DireccionEmpleado { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Teléfono de Empleado")]
        public string TelefonoEmpleado { get; set; }

        [Required]
        [Column(TypeName = "Varchar(100)")]
        [Display(Name = "Correo")]
        public string Correo { get; set; }
    }
}
