﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Proyecto.Migrations
{
    public partial class tablas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbl_Clientes",
                columns: table => new
                {
                    IdCLientes = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombreCliente = table.Column<string>(type: "Varchar(100)", nullable: false),
                    ApelldioCliente = table.Column<string>(type: "varchar(100)", nullable: false),
                    NIT = table.Column<string>(type: "Varchar(100)", nullable: false),
                    DireccionCliente = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Categoria = table.Column<string>(type: "Varchar(75)", nullable: false),
                    Estado = table.Column<string>(type: "Varchar(15)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Clientes", x => x.IdCLientes);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Proveedores",
                columns: table => new
                {
                    IdProveedor = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proveedor = table.Column<string>(type: "Varchar(100)", nullable: false),
                    DireccionProveedor = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Telefono = table.Column<string>(type: "Varchar(15)", nullable: false),
                    Correo = table.Column<string>(type: "Varchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Proveedores", x => x.IdProveedor);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Puesto",
                columns: table => new
                {
                    IdPuesto = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombrePuesto = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Salario = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Puesto", x => x.IdPuesto);
                });

            migrationBuilder.CreateTable(
                name: "tbl_producto",
                columns: table => new
                {
                    IdProducto = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdProveedor = table.Column<int>(type: "int", nullable: false),
                    NombreProducto = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Descripcion = table.Column<string>(type: "Varchar(150)", nullable: false),
                    Fecha = table.Column<DateTime>(type: "DateTime", nullable: false),
                    UbicacionFisica = table.Column<string>(type: "Varchar(150)", nullable: false),
                    Existencia = table.Column<int>(type: "int", nullable: false),
                    Precio = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_producto", x => x.IdProducto);
                    table.ForeignKey(
                        name: "FK_tbl_producto_tbl_Proveedores_IdProveedor",
                        column: x => x.IdProveedor,
                        principalTable: "tbl_Proveedores",
                        principalColumn: "IdProveedor",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Empleado",
                columns: table => new
                {
                    IdEmpleado = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdPuesto = table.Column<int>(type: "int", nullable: false),
                    NombreEmpleado = table.Column<string>(type: "Varchar(100)", nullable: false),
                    ApellidoEmpleado = table.Column<string>(type: "Varchar(100)", nullable: false),
                    DireccionEmpleado = table.Column<string>(type: "Varchar(150)", nullable: false),
                    TelefonoEmpleado = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Correo = table.Column<string>(type: "Varchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Empleado", x => x.IdEmpleado);
                    table.ForeignKey(
                        name: "FK_tbl_Empleado_tbl_Puesto_IdPuesto",
                        column: x => x.IdPuesto,
                        principalTable: "tbl_Puesto",
                        principalColumn: "IdPuesto",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Login",
                columns: table => new
                {
                    IdUsuario = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdEmpleado = table.Column<int>(type: "int", nullable: false),
                    correoUsuario = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Password = table.Column<string>(type: "Varchar(25)", nullable: false),
                    Perfil = table.Column<string>(type: "Varchar(50)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Login", x => x.IdUsuario);
                    table.ForeignKey(
                        name: "FK_tbl_Login_tbl_Empleado_IdEmpleado",
                        column: x => x.IdEmpleado,
                        principalTable: "tbl_Empleado",
                        principalColumn: "IdEmpleado",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbl_Ventas",
                columns: table => new
                {
                    IdVentas = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdEmpleado = table.Column<int>(type: "int", nullable: false),
                    IdClientes = table.Column<int>(type: "int", nullable: false),
                    Fecha = table.Column<DateTime>(type: "Date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_Ventas", x => x.IdVentas);
                    table.ForeignKey(
                        name: "FK_tbl_Ventas_tbl_Clientes_IdClientes",
                        column: x => x.IdClientes,
                        principalTable: "tbl_Clientes",
                        principalColumn: "IdCLientes",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbl_Ventas_tbl_Empleado_IdEmpleado",
                        column: x => x.IdEmpleado,
                        principalTable: "tbl_Empleado",
                        principalColumn: "IdEmpleado",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbl_DetalleVenta",
                columns: table => new
                {
                    IdDetalleVenta = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdVentas = table.Column<int>(type: "int", nullable: false),
                    IdProducto = table.Column<int>(type: "int", nullable: false),
                    Cantidad = table.Column<int>(type: "int", nullable: false),
                    Precio = table.Column<double>(type: "float", nullable: false),
                    PrecioTotal = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_DetalleVenta", x => x.IdDetalleVenta);
                    table.ForeignKey(
                        name: "FK_tbl_DetalleVenta_tbl_producto_IdProducto",
                        column: x => x.IdProducto,
                        principalTable: "tbl_producto",
                        principalColumn: "IdProducto",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbl_DetalleVenta_tbl_Ventas_IdVentas",
                        column: x => x.IdVentas,
                        principalTable: "tbl_Ventas",
                        principalColumn: "IdVentas",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbl_NotaCredito",
                columns: table => new
                {
                    IdNotaCredito = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombreEmpresa = table.Column<string>(type: "Varchar(100)", nullable: false),
                    NIT = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Direccion = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Telefono = table.Column<string>(type: "Varchar(100)", nullable: false),
                    IdEmpleado = table.Column<int>(type: "int", nullable: false),
                    IdClientes = table.Column<int>(type: "int", nullable: false),
                    IdVentas = table.Column<int>(type: "int", nullable: false),
                    Fecha = table.Column<DateTime>(type: "DateTime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_NotaCredito", x => x.IdNotaCredito);
                    table.ForeignKey(
                        name: "FK_tbl_NotaCredito_tbl_Clientes_IdClientes",
                        column: x => x.IdClientes,
                        principalTable: "tbl_Clientes",
                        principalColumn: "IdCLientes",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbl_NotaCredito_tbl_Empleado_IdEmpleado",
                        column: x => x.IdEmpleado,
                        principalTable: "tbl_Empleado",
                        principalColumn: "IdEmpleado",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbl_NotaCredito_tbl_Ventas_IdVentas",
                        column: x => x.IdVentas,
                        principalTable: "tbl_Ventas",
                        principalColumn: "IdVentas"
                        );
                });

            migrationBuilder.CreateTable(
                name: "tbl_DetalleCredito",
                columns: table => new
                {
                    IdDetalleCredito = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdNotaCredito = table.Column<int>(type: "int", nullable: false),
                    IdProducto = table.Column<int>(type: "int", nullable: false),
                    Descripcion = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Cantidad = table.Column<int>(type: "int", nullable: false),
                    SubTotal = table.Column<double>(type: "float", nullable: false),
                    IVA = table.Column<double>(type: "float", nullable: false),
                    Total = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_DetalleCredito", x => x.IdDetalleCredito);
                    table.ForeignKey(
                        name: "FK_tbl_DetalleCredito_tbl_NotaCredito_IdNotaCredito",
                        column: x => x.IdNotaCredito,
                        principalTable: "tbl_NotaCredito",
                        principalColumn: "IdNotaCredito",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbl_DetalleCredito_tbl_producto_IdProducto",
                        column: x => x.IdProducto,
                        principalTable: "tbl_producto",
                        principalColumn: "IdProducto",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tbl_DetalleCredito_IdNotaCredito",
                table: "tbl_DetalleCredito",
                column: "IdNotaCredito");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_DetalleCredito_IdProducto",
                table: "tbl_DetalleCredito",
                column: "IdProducto");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_DetalleVenta_IdProducto",
                table: "tbl_DetalleVenta",
                column: "IdProducto");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_DetalleVenta_IdVentas",
                table: "tbl_DetalleVenta",
                column: "IdVentas");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_Empleado_IdPuesto",
                table: "tbl_Empleado",
                column: "IdPuesto");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_Login_IdEmpleado",
                table: "tbl_Login",
                column: "IdEmpleado");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_NotaCredito_IdClientes",
                table: "tbl_NotaCredito",
                column: "IdClientes");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_NotaCredito_IdEmpleado",
                table: "tbl_NotaCredito",
                column: "IdEmpleado");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_NotaCredito_IdVentas",
                table: "tbl_NotaCredito",
                column: "IdVentas");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_producto_IdProveedor",
                table: "tbl_producto",
                column: "IdProveedor");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_Ventas_IdClientes",
                table: "tbl_Ventas",
                column: "IdClientes");

            migrationBuilder.CreateIndex(
                name: "IX_tbl_Ventas_IdEmpleado",
                table: "tbl_Ventas",
                column: "IdEmpleado");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_DetalleCredito");

            migrationBuilder.DropTable(
                name: "tbl_DetalleVenta");

            migrationBuilder.DropTable(
                name: "tbl_Login");

            migrationBuilder.DropTable(
                name: "tbl_NotaCredito");

            migrationBuilder.DropTable(
                name: "tbl_producto");

            migrationBuilder.DropTable(
                name: "tbl_Ventas");

            migrationBuilder.DropTable(
                name: "tbl_Proveedores");

            migrationBuilder.DropTable(
                name: "tbl_Clientes");

            migrationBuilder.DropTable(
                name: "tbl_Empleado");

            migrationBuilder.DropTable(
                name: "tbl_Puesto");
        }
    }
}
